<?php
/**
 * customer_gallery.php
 * 
 * Returns all walk photos for a customer, plus a shareable gallery token.
 * 
 * GET ?email=customer@email.com  — authenticated customer view
 * GET ?token=abc123              — public shareable gallery
 */

header('Content-Type: application/json');
date_default_timezone_set('America/New_York');

try {
    $dbPath = __DIR__ . '/../data/dogwalker.sqlite';
    $db = new PDO('sqlite:' . $dbPath);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create gallery_tokens table if needed
    $db->exec("CREATE TABLE IF NOT EXISTS gallery_tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL,
        token TEXT NOT NULL UNIQUE,
        created_at TEXT DEFAULT (datetime('now')),
        dog_names TEXT
    )");

    $email = $_GET['email'] ?? '';
    $token = $_GET['token'] ?? '';

    // Resolve email from token
    if ($token && !$email) {
        $stmt = $db->prepare("SELECT email, dog_names FROM gallery_tokens WHERE token = ?");
        $stmt->execute([$token]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            echo json_encode(['error' => 'Invalid gallery link']);
            exit;
        }
        $email = $row['email'];
        $dogNames = $row['dog_names'];
    }

    if (!$email) {
        echo json_encode(['error' => 'email or token required']);
        exit;
    }

    // Get customer info
    $custStmt = $db->prepare("SELECT name, dogs FROM customers WHERE LOWER(email) = LOWER(?)");
    $custStmt->execute([$email]);
    $cust = $custStmt->fetch(PDO::FETCH_ASSOC);
    $dogNames = $dogNames ?? ($cust['dogs'] ?? $cust['name'] ?? '');

    // Get all completed bookings with photos
    $stmt = $db->prepare("
        SELECT b.id, b.date, b.type, b.start, b.photo1, b.photo2, 
               b.visitNote, b.pottyPee, b.pottyPoop,
               w.name AS walker_name
        FROM bookings b
        LEFT JOIN walkers w ON b.walker_id = w.id
        WHERE b.nickname = (SELECT name FROM customers WHERE LOWER(email) = LOWER(?))
          AND (b.photo1 IS NOT NULL OR b.photo2 IS NOT NULL)
          AND b.status = 'completed'
        ORDER BY b.date DESC
    ");
    $stmt->execute([$email]);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $photos = [];
    foreach ($bookings as $b) {
        $date = $b['date'] ? date('M j, Y', strtotime($b['date'])) : '';
        $base = [
            'bookingId' => $b['id'],
            'date' => $date,
            'rawDate' => $b['date'],
            'type' => $b['type'],
            'walker' => $b['walker_name'] ?: '',
            'note' => $b['visitNote'] ?: '',
        ];
        if ($b['photo1']) {
            $photos[] = array_merge($base, ['file' => $b['photo1'], 'index' => 1]);
        }
        if ($b['photo2']) {
            $photos[] = array_merge($base, ['file' => $b['photo2'], 'index' => 2]);
        }
    }

    // Generate or retrieve share token
    $shareToken = '';
    $tStmt = $db->prepare("SELECT token FROM gallery_tokens WHERE LOWER(email) = LOWER(?)");
    $tStmt->execute([$email]);
    $existing = $tStmt->fetchColumn();
    if ($existing) {
        $shareToken = $existing;
    } else {
        $shareToken = bin2hex(random_bytes(12));
        $db->prepare("INSERT INTO gallery_tokens (email, token, dog_names) VALUES (?, ?, ?)")
            ->execute([$email, $shareToken, $dogNames]);
    }

    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'retiredguydogwalker.com';

    echo json_encode([
        'success' => true,
        'dogNames' => $dogNames,
        'photos' => $photos,
        'totalPhotos' => count($photos),
        'shareToken' => $shareToken,
        'shareUrl' => "{$protocol}://{$host}/?gallery={$shareToken}",
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
