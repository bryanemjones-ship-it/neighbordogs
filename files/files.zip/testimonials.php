<?php
/**
 * testimonials.php
 * 
 * GET — returns all testimonials (public)
 * POST — add/edit/delete (admin only)
 */

header('Content-Type: application/json');
$path = __DIR__ . '/../data/testimonials.json';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!file_exists($path)) {
        echo json_encode([]);
        exit;
    }
    echo file_get_contents($path);
    exit;
}

// POST — admin only
session_start();
if (empty($_SESSION['admin_authenticated'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Admin required']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

$testimonials = file_exists($path) ? json_decode(file_get_contents($path), true) : [];
if (!is_array($testimonials)) $testimonials = [];

switch ($action) {
    case 'add':
        $testimonials[] = [
            'name'  => trim($input['name'] ?? ''),
            'dogs'  => trim($input['dogs'] ?? ''),
            'text'  => trim($input['text'] ?? ''),
            'stars' => (int)($input['stars'] ?? 5),
        ];
        break;

    case 'edit':
        $idx = (int)($input['index'] ?? -1);
        if (isset($testimonials[$idx])) {
            $testimonials[$idx] = [
                'name'  => trim($input['name'] ?? ''),
                'dogs'  => trim($input['dogs'] ?? ''),
                'text'  => trim($input['text'] ?? ''),
                'stars' => (int)($input['stars'] ?? 5),
            ];
        }
        break;

    case 'delete':
        $idx = (int)($input['index'] ?? -1);
        if (isset($testimonials[$idx])) {
            array_splice($testimonials, $idx, 1);
        }
        break;

    case 'reorder':
        $order = $input['order'] ?? [];
        $reordered = [];
        foreach ($order as $i) {
            if (isset($testimonials[$i])) $reordered[] = $testimonials[$i];
        }
        $testimonials = $reordered;
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Unknown action']);
        exit;
}

file_put_contents($path, json_encode($testimonials, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
echo json_encode(['success' => true, 'count' => count($testimonials)]);
