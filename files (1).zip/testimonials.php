<?php
/**
 * testimonials.php — Retired Guy Dog Walker
 * GET  → returns array of testimonials
 * POST → {action:"add", name, dogs, text, stars} or {action:"delete", index}
 * Admin actions require authenticated session.
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Credentials: true');

$dataFile = __DIR__ . '/../data/testimonials.json';

// Load testimonials from JSON file
function loadTestimonials($file) {
    if (!file_exists($file)) return [];
    $raw = file_get_contents($file);
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// Save testimonials to JSON file
function saveTestimonials($file, $data) {
    $dir = dirname($file);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    file_put_contents($file, json_encode(array_values($data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// Check admin session
function isAdmin() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    return !empty($_SESSION['admin_authenticated']);
}

// ── GET: return all testimonials ──
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo json_encode(loadTestimonials($dataFile));
    exit;
}

// ── POST: add or delete (admin only) ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isAdmin()) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized', 'authRequired' => true]);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';
    $testimonials = loadTestimonials($dataFile);

    if ($action === 'add') {
        $name  = trim($input['name']  ?? '');
        $dogs  = trim($input['dogs']  ?? '');
        $text  = trim($input['text']  ?? '');
        $stars = max(1, min(5, intval($input['stars'] ?? 5)));

        if ($name === '' || $text === '') {
            http_response_code(400);
            echo json_encode(['error' => 'Name and text are required.']);
            exit;
        }

        $testimonials[] = [
            'name'  => $name,
            'dogs'  => $dogs,
            'text'  => $text,
            'stars' => $stars
        ];

        saveTestimonials($dataFile, $testimonials);
        echo json_encode(['success' => true, 'count' => count($testimonials)]);
        exit;
    }

    if ($action === 'delete') {
        $index = intval($input['index'] ?? -1);
        if ($index < 0 || $index >= count($testimonials)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid index.']);
            exit;
        }

        array_splice($testimonials, $index, 1);
        saveTestimonials($dataFile, $testimonials);
        echo json_encode(['success' => true, 'count' => count($testimonials)]);
        exit;
    }

    http_response_code(400);
    echo json_encode(['error' => 'Unknown action.']);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed.']);
