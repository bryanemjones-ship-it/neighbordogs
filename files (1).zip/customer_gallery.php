<?php
/**
 * customer_gallery.php — Retired Guy Dog Walker
 * GET ?email=EMAIL  → photos for a logged-in returning customer
 * GET ?token=TOKEN  → photos for a shared gallery link (public)
 *
 * Returns: {success, photos: [{file, date, rawDate}], dogNames, totalPhotos, shareUrl}
 * Creates gallery_tokens table in SQLite on first use.
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Credentials: true');

$dbPath = __DIR__ . '/../data/database.sqlite';

if (!file_exists($dbPath)) {
    echo json_encode(['success' => false, 'error' => 'Database not found.']);
    exit;
}

try {
    $db = new PDO('sqlite:' . $dbPath);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed.']);
    exit;
}

// Ensure gallery_tokens table exists
$db->exec("CREATE TABLE IF NOT EXISTS gallery_tokens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    token TEXT NOT NULL UNIQUE,
    created_at TEXT DEFAULT (datetime('now'))
)");

$email = $_GET['email'] ?? '';
$token = $_GET['token'] ?? '';

// ── Resolve email from token ──
if ($token !== '' && $email === '') {
    $stmt = $db->prepare("SELECT email FROM gallery_tokens WHERE token = ?");
    $stmt->execute([$token]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        echo json_encode(['success' => false, 'error' => 'Invalid or expired gallery link.']);
        exit;
    }
    $email = $row['email'];
}

if ($email === '') {
    echo json_encode(['success' => false, 'error' => 'Email or token required.']);
    exit;
}

$emailLower = strtolower(trim($email));

// ── Look up customer ──
$custStmt = $db->prepare("SELECT name, dogs FROM customers WHERE LOWER(email) = ?");
$custStmt->execute([$emailLower]);
$customer = $custStmt->fetch(PDO::FETCH_ASSOC);

if (!$customer) {
    echo json_encode(['success' => false, 'photos' => [], 'dogNames' => '', 'totalPhotos' => 0]);
    exit;
}

$customerName = $customer['name'] ?? '';
$dogNames     = $customer['dogs'] ?? '';

// ── Get or create share token ──
$tokStmt = $db->prepare("SELECT token FROM gallery_tokens WHERE LOWER(email) = ?");
$tokStmt->execute([$emailLower]);
$tokRow = $tokStmt->fetch(PDO::FETCH_ASSOC);

if ($tokRow) {
    $shareToken = $tokRow['token'];
} else {
    $shareToken = bin2hex(random_bytes(16));
    $ins = $db->prepare("INSERT INTO gallery_tokens (email, token) VALUES (?, ?)");
    $ins->execute([trim($email), $shareToken]);
}

$shareUrl = 'https://retiredguydogwalker.com/?gallery=' . $shareToken;

// ── Fetch photos from bookings ──
// Bookings are linked to customers by nickname (which matches customer name)
$photoStmt = $db->prepare("
    SELECT photo1, photo2, date
    FROM bookings
    WHERE nickname = ?
      AND (photo1 IS NOT NULL AND photo1 != '' OR photo2 IS NOT NULL AND photo2 != '')
    ORDER BY date DESC, id DESC
");
$photoStmt->execute([$customerName]);
$rows = $photoStmt->fetchAll(PDO::FETCH_ASSOC);

$photos = [];
foreach ($rows as $row) {
    $rawDate = $row['date'] ?? '';
    $dateFmt = '';
    if ($rawDate) {
        $ts = strtotime($rawDate);
        if ($ts) $dateFmt = date('M j, Y', $ts);
    }

    if (!empty($row['photo1'])) {
        $photos[] = [
            'file'    => $row['photo1'],
            'date'    => $dateFmt,
            'rawDate' => $rawDate
        ];
    }
    if (!empty($row['photo2'])) {
        $photos[] = [
            'file'    => $row['photo2'],
            'date'    => $dateFmt,
            'rawDate' => $rawDate
        ];
    }
}

echo json_encode([
    'success'     => true,
    'photos'      => $photos,
    'dogNames'    => $dogNames,
    'totalPhotos' => count($photos),
    'shareUrl'    => $shareUrl
]);
